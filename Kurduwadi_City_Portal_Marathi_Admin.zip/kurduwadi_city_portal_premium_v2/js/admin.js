const CONFIG={url:'YOUR_SUPABASE_URL',key:'YOUR_SUPABASE_ANON_KEY'};
const ready=CONFIG.url.startsWith('http')&&CONFIG.key!=='YOUR_SUPABASE_ANON_KEY';
const sb=ready?supabase.createClient(CONFIG.url,CONFIG.key):null;
const $=id=>document.getElementById(id);
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();if(!sb){$('loginMsg').textContent='आधी js/admin.js मध्ये Supabase URL आणि Anon Key भरा.';return}const {error}=await sb.auth.signInWithPassword({email:$('email').value,password:$('password').value});if(error){$('loginMsg').textContent='लॉगिन अयशस्वी: '+error.message;return}showDashboard()});
$('logout').onclick=async()=>{if(sb) await sb.auth.signOut();location.reload()};
async function showDashboard(){ $('loginBox').hidden=true;$('dashboard').hidden=false;if(!sb)return;const {data,error}=await sb.from('profiles').select('*').eq('status','pending').order('created_at',{ascending:false});if(error){$('pending').textContent='डेटा लोड करताना त्रुटी: '+error.message;return}$('stats').innerHTML='<p><strong>प्रलंबित प्रोफाइल:</strong> '+data.length+'</p>';if(!data.length){$('pending').textContent='प्रलंबित प्रोफाइल नाहीत.';return}$('pending').innerHTML=data.map(p=>`<div class="card" style="margin:12px 0"><b>${esc(p.full_name)}</b><br>शिक्षण: ${esc(p.education||'-')}<br>व्यवसाय: ${esc(p.job||'-')}<br>शहर: ${esc(p.city||'-')}<br>कौशल्ये: ${esc(p.skills||'-')}<br><button class="btn" onclick="review('${p.id}','approved')">मंजूर</button> <button class="btn" onclick="review('${p.id}','rejected')">नकार</button></div>`).join('')}
window.review=async(id,status)=>{const {error}=await sb.from('profiles').update({status}).eq('id',id);if(error)alert(error.message);else showDashboard()};
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
(async()=>{if(sb){const {data}=await sb.auth.getSession();if(data.session)showDashboard()}})();
