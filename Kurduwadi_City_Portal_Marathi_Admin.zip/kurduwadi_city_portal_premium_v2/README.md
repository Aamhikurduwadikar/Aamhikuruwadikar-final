# कुर्डुवाडी सिटी पोर्टल — मराठी Premium Version

हा प्रकल्प कुर्डुवाडी शहरासाठी मराठी-first, mobile-friendly civic portal आहे.

## मुख्य भाग
- मुखपृष्ठ, इतिहास, नगरपालिका, शासकीय कार्यालये
- सेवा व सुविधा, शिक्षण, आरोग्य, बसस्थानक, रेल्वे स्टेशन
- धार्मिक स्थळे, फोटो गॅलरी, स्थानिक बातम्या/कार्यक्रम
- नागरिक स्वतःची प्रोफाइल नोंदवू शकतात
- नाव, शिक्षण, व्यवसाय, शहर, राज्य, देश, कौशल्ये यावर नागरिक शोध
- रक्तगट/फोनसाठी privacy consent
- Pending → Admin Verification → Approved/Rejected workflow
- Supabase PostgreSQL + Auth साठी तयार
- admin/index.html मध्ये प्रशासक लॉगिन व Pending प्रोफाइल मंजुरी/नकार

## Supabase सेटअप
1. Supabase मध्ये नवीन project तयार करा.
2. database/schema.sql पूर्ण SQL Editor मध्ये चालवा.
3. Authentication मध्ये Admin user तयार करा.
4. त्या user चा UUID admin_profiles मध्ये admin म्हणून जोडा.
5. js/app.js, js/profile.js, js/directory.js आणि js/admin.js मधील Supabase URL व anon key भरा.
6. **service_role key frontend मध्ये कधीही ठेवू नका.**

## Hosting
Vercel / Netlify / Cloudflare Pages सारख्या static hosting वर deploy करता येईल. Custom domain जोडल्यावर 24/7 online ठेवता येईल.

## सुरक्षा
Production मध्ये RLS policies, admin role checks, spam/rate limiting, email verification आणि नियमित database backup सक्षम करा.
